#!/bin/bash

# CONFIG
CONTAINER="kafka1"
TOPIC="test-topic5"
BOOTSTRAP="kafka1:9092"
REPLICATION_FACTOR=3
PARTITIONS=70
KAFKA_BIN="/opt/kafka/bin/kafka-topics.sh"
# Set to "true" if you REALLY want deletion each run
DELETE_TOPIC=false

echo "[$(date)] Starting Kafka topic job..."

# Check if topic exists
docker exec "$CONTAINER"  kafka-topics \
  --bootstrap-server "$BOOTSTRAP" \
  --list | grep -w "$TOPIC" > /dev/null 2>&1

if [ $? -ne 0 ]; then
  echo "[$(date)] Creating topic: $TOPIC"
  docker exec "$CONTAINER"  kafka-topics \
    --create \
    --topic "$TOPIC" \
    --bootstrap-server "$BOOTSTRAP" \
    --replication-factor "$REPLICATION_FACTOR" \
    --partitions "$PARTITIONS"
else
  echo "[$(date)] Topic already exists: $TOPIC"
fi

# Describe topic
echo "[$(date)] Describing topic: $TOPIC"
docker exec "$CONTAINER"  kafka-topics \
  --describe \
  --topic "$TOPIC" \
  --bootstrap-server "$BOOTSTRAP"

# Optional delete
if [ "$DELETE_TOPIC" = true ]; then
  echo "[$(date)] Deleting topic: $TOPIC"
  docker exec "$CONTAINER"  kafka-topics \
    --delete \
    --topic "$TOPIC" \
    --bootstrap-server "$BOOTSTRAP"
fi

echo "[$(date)] Kafka topic job complete."
echo "----------------------------------------"
