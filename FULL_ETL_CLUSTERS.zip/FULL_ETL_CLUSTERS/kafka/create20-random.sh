#!/bin/bash

# CONFIG
CONTAINER="kafka-krt1"
BOOTSTRAP="kafka-krt1:9092"
REPLICATION_FACTOR=3
PARTITIONS=50
KAFKA_BIN="/opt/kafka/bin/kafka-topics.sh"
DELETE_TOPIC=false

echo "[$(date)] Starting Bulk Kafka topic job..."

# Loop 20 times
for i in {1..20}
do
    # Generate a random suffix (e.g., telemetry-a7b2)
    RANDOM_ID=$(head /dev/urandom | tr -dc a-z0-9 | head -c 4)
    TOPIC="topic-${RANDOM_ID}"

    echo "----------------------------------------"
    echo "[$(date)] Processing Topic $i/20: $TOPIC"

    # Check if topic exists
    docker exec "$CONTAINER" "$KAFKA_BIN" \
      --bootstrap-server "$BOOTSTRAP" \
      --list | grep -w "$TOPIC" > /dev/null 2>&1

    if [ $? -ne 0 ]; then
      echo "[$(date)] Creating topic: $TOPIC"
      docker exec "$CONTAINER" "$KAFKA_BIN" \
        --create \
        --topic "$TOPIC" \
        --bootstrap-server "$BOOTSTRAP" \
        --replication-factor "$REPLICATION_FACTOR" \
        --partitions "$PARTITIONS"
    else
      echo "[$(date)] Topic already exists: $TOPIC"
    fi

    # Describe topic
    docker exec "$CONTAINER" "$KAFKA_BIN" \
      --describe \
      --topic "$TOPIC" \
      --bootstrap-server "$BOOTSTRAP"

    # Optional delete
    if [ "$DELETE_TOPIC" = true ]; then
      echo "[$(date)] Deleting topic: $TOPIC"
      docker exec "$CONTAINER" "$KAFKA_BIN" \
        --delete \
        --topic "$TOPIC" \
        --bootstrap-server "$BOOTSTRAP"
    fi
done

echo "----------------------------------------"
echo "[$(date)] Bulk Kafka topic job complete."
