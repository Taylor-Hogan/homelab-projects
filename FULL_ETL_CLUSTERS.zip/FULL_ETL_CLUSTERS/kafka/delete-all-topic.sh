#!/bin/bash

# CONFIG
CONTAINER="kafka-krt1"
BOOTSTRAP="kafka-krt1:9092"
KAFKA_BIN="/opt/kafka/bin/kafka-topics.sh"

echo "[$(date)] Starting Global Kafka Topic Wipeout..."
echo "Connecting to: $BOOTSTRAP"

# 1. Get the full list of topics from the broker
# We filter out internal topics (starting with __) to keep the cluster stable
TOPICS=$(docker exec "$CONTAINER" "$KAFKA_BIN" --bootstrap-server "$BOOTSTRAP" --list | grep -v "^__")

if [ -z "$TOPICS" ]; then
    echo "[$(date)] No user topics found to delete."
    exit 0
fi

# 2. Loop through and delete
for TOPIC in $TOPICS
do
    echo "----------------------------------------"
    echo "[$(date)] Deleting topic: $TOPIC"
    
    docker exec "$CONTAINER" "$KAFKA_BIN" \
      --delete \
      --topic "$TOPIC" \
      --bootstrap-server "$BOOTSTRAP"
    
    if [ $? -eq 0 ]; then
        echo "SUCCESS: $TOPIC is gone."
    else
        echo "FAILED: Could not delete $TOPIC."
    fi
done

echo "----------------------------------------"
echo "[$(date)] All user-defined topics have been cleared."
