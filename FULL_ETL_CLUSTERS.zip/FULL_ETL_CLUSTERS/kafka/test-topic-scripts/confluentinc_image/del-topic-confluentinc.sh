#!/bin/bash

# CONFIG
CONTAINER="kafka-krt1"
TOPIC="test-topic5"
BOOTSTRAP="kafka-krt1:9092"
REPLICATION_FACTOR=3
PARTITIONS=7
KAFKA_BIN="/opt/kafka/bin/kafka-topics.sh"
# Set to "true" if you REALLY want deletion each run
DELETE_TOPIC=true

echo "[$(date)] Starting Kafka topic job..."

# Optional delete
if [ "$DELETE_TOPIC" = true ]; then
  echo "[$(date)] Deleting topic: $TOPIC"
  docker exec "$CONTAINER"  kafka-topics \
    --delete \
    --topic "$TOPIC" \
    --bootstrap-server "$BOOTSTRAP"
fi

echo "[$(date)] Kafka topic job complete."
echo "----------------------------------------"
