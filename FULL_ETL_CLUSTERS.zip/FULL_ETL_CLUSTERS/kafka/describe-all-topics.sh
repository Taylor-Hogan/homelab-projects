#!/bin/bash

# CONFIG
CONTAINER="kafka-krt1"
BOOTSTRAP="kafka-krt1:9092"
KAFKA_BIN="/opt/kafka/bin/kafka-topics.sh"

echo "[$(date)] --- START: FULL CLUSTER TOPIC DESCRIPTION ---"
echo "Connecting to: $BOOTSTRAP"
echo "--------------------------------------------------------"

# Running describe without a --topic flag describes all topics
docker exec "$CONTAINER" "$KAFKA_BIN" \
  --describe \
  --bootstrap-server "$BOOTSTRAP"

echo "--------------------------------------------------------"
echo "[$(date)] --- END: FULL CLUSTER TOPIC DESCRIPTION ---"
