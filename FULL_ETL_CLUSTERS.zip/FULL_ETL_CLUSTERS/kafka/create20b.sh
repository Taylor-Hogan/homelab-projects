#!/bin/bash

# CONFIG
CONTAINER="kafka-krt1"
BOOTSTRAP="kafka-krt1:9092"
REPLICATION_FACTOR=3
PARTITIONS=50
KAFKA_BIN="/opt/kafka/bin/kafka-topics.sh"

echo "[$(date)] Starting sequential topic generation..."

for i in {1..20}
do
    # This creates a clean name: demo-topic1, demo-topic2, etc.
    TOPIC="demo-topic${i}"

    # Check if topic exists
    docker exec "$CONTAINER" "$KAFKA_BIN" \
      --bootstrap-server "$BOOTSTRAP" \
      --list | grep -w "$TOPIC" > /dev/null 2>&1

    if [ $? -ne 0 ]; then
      echo "[$i/20] Creating: $TOPIC"
      docker exec "$CONTAINER" "$KAFKA_BIN" \
        --create \
        --topic "$TOPIC" \
        --bootstrap-server "$BOOTSTRAP" \
        --replication-factor "$REPLICATION_FACTOR" \
        --partitions "$PARTITIONS"
    else
      echo "[$i/20] Skipping: $TOPIC (Already exists)"
    fi
done

echo "[$(date)] Generation of 20 demo-topics complete."
