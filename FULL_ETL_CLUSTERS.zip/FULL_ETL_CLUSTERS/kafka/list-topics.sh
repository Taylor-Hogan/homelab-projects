
FKA_TOPICS=$(docker exec kafka1 which kafka-topics.sh 2>/dev/null)

if [ -z "$KAFKA_TOPICS" ]; then
	  KAFKA_TOPICS="/opt/kafka/bin/kafka-topics.sh"
fi

docker exec kafka1 $KAFKA_TOPICS --list --bootstrap-server kafka1:9092
